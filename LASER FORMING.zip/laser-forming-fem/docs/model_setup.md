# Model Set-up

## Geometry and mesh

- Rectangular plate, **150 × 150 × 6 mm**.
- Structured hexahedral mesh: **30 × 30 elements** in-plane, each 5 × 5 mm, extruded through the thickness.
- The mesh resolves the localised temperature gradient while keeping run time short. It is coarse, and no mesh-convergence study was done.

## Analysis chain (ANSYS Workbench)

1. **Transient Thermal**
   - Initial condition: uniform ambient temperature.
   - Heat flux applied on a moving square patch of surface elements (see [`moving_heat_source.md`](moving_heat_source.md)).
   - Cooling: natural convection to ambient on exposed faces; no radiation.
2. **Transient Structural**
   - The temperature history from the thermal analysis is imported as a load (**one-way coupling**).
   - The plate is held at one end so the free part can bend.
   - Material: structural steel, constant properties, linear elastic.

## Case-study parameters

| Parameter | Value |
|---|---|
| Beam diameter / patch | 15 mm (3 × 3 elements) |
| Scan speed | 15 mm/s |
| Laser power | 1500 W, taken as fully absorbed |
| Scan length | 150 mm (10 steps of 1 s) |
| Simulated time | about 15 s (heating plus cooling) |

## Why one-way coupling?

Deformation here is tiny compared with the plate size, so it barely changes the heat flow. Passing temperature to the structural analysis, and not the reverse, is a standard simplification.

## Why these values?

The parameters were chosen to give a moderate-to-high heat input so that thermal gradients and deformation are clearly visible. Starting values were selected with AI assistance and then refined by trial and checked against physical reasoning. They are illustrative and not tuned to a specific steel grade or experiment.

# Influence of Process Parameters

Each process parameter has a direct input in the model, so its influence can be studied by changing one input at a time and comparing the outputs: peak temperature, through-thickness gradient and maximum deformation.

## How each parameter is set and what theory expects

| Parameter | Model input | Expected trend |
|---|---|---|
| **Laser power** | Heat flux `q = P / d²` | Higher power gives higher heat input, higher peak temperature and gradient, and more bending |
| **Scan speed** | Step time `dt = d / v` | Lower speed gives more heat per unit length, a higher temperature rise and more bending; higher speed reduces deformation |
| **Beam diameter** | Patch size `n × n` elements | Larger beam gives a wider heat-affected zone and a smoother gradient; smaller beam gives a concentrated zone and sharper gradients |
| **Number of irradiations (passes)** | Repeat the patch sequence over the same path | Bending accumulates with each pass; later passes change as the plate is already hot and deformed |
| **Plate thickness** | Extrusion thickness of the geometry | Thicker plate resists bending (smaller curvature, `kappa ~ alpha * dT / t`); thinner plates bend more for the same loading |
| **Material properties** | Conductivity, specific heat, thermal expansion, Young's modulus | Higher `alpha` bends more; higher `k` flattens the gradient; higher `E` raises stress for the same strain |

The trends above are the expected behaviour from laser forming theory (see references in the README). They are compared with the simulation results in the run log below.

## Heat input per unit length

A useful summary of power and speed together is the line energy:

```
line energy = P / v
```

Case study: `1500 W / 15 mm/s = 100 J/mm`. Halving the speed (or doubling the power) doubles it.

## Run log

One row per simulation. Values are read from the same kinds of plots as the case study: the temperature–time probe plot and the total-deformation result.

| Run | Beam [mm] | Speed [mm/s] | Power [W] | Passes | Peak temperature [°C] | Max deformation [mm] | Matches expected trend? |
|---|---|---|---|---|---|---|---|
| A (case study) | 15 | 15 | 1500 | 1 | ≈ 446 (probe, t ≈ 6 s); ≈ 531 (field max, t = 6.9 s) | ≈ 0.12 (t = 7.37 s) | Reference case |
| B | | | | | | | |
| C | | | | | | | |
| D | | | | | | | |

Add each additional run as a new row with the exact parameters used and the numbers read from the results. Compare against the "Expected trend" column above and state clearly whether it matches. Rows that were not run should be removed, so every claim in this repository is backed by data.

## Reading the comparison honestly

- Temperature and deformation are compared **in trend** with the literature, not in magnitude against experiments.
- Changing patch size changes both the beam diameter and the flux per area; keep the power fixed (`q = P / d²`) so only the beam size changes.
- The model is elastic with constant properties, so deformation values are transient bending tendencies and not permanent bend angles.

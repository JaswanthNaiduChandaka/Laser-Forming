# Mechanisms and Physics

## Deformation mechanisms

| Mechanism | When it dominates | Result |
|---|---|---|
| **Temperature Gradient Mechanism (TGM)** | Thick plate, small beam, fast scan: steep gradient through the thickness | Bends towards the laser after cooling (counter-bends away during heating) |
| **Buckling Mechanism (BM)** | Thin sheet, beam much larger than thickness, near-uniform temperature through thickness | Out-of-plane buckling; direction depends on boundary conditions |
| **Upsetting Mechanism (UM)** | Thick, stiff part heated uniformly | Thickening and in-plane shortening, little bending |

A 6 mm plate with a moving 15 mm beam gives a strong through-thickness gradient, so TGM is the mechanism this model is meant to show.

## Governing equations (solved by ANSYS, not coded by us)

**Heat conduction**

```
rho * c * dT/dt = div( k * grad T )
```

with a surface heat flux `q` on the laser patch and convection `h (T - T_inf)` on the other faces.

**Thermal strain**

```
eps_th = alpha * dT
```

**Quasi-static structure**

```
div(sigma) = 0,      sigma = D (eps - eps_th)
```

The temperature history from the thermal analysis is applied as a load in the structural analysis (one-way coupling). In finite element form, the solver assembles:

```
[C]{dT/dt} + [K]{T} = {Q}          (heat)
[K]{u} = {F_thermal}               (displacement)
```

solved step by step in time.

## Simple scaling used to interpret results

```
curvature  kappa  ~  alpha * dT / t
```

A larger through-thickness temperature difference `dT` bends more; a thicker plate (`t`) bends less. This is a trend relation, not an exact bend-angle formula.

# Moving Heat Source: Step-wise Heat-Flux Method

## Problem

A laser moves continuously along the plate. ANSYS Workbench has no ready-made moving heat source, and a continuous moving load needs APDL or a user-defined function.

## Approach

Split the scan into time steps and load one patch of surface elements per step:

```
step 1:  patch 1 ON  (0 - d)        for dt seconds, then OFF
step 2:  patch 2 ON  (d - 2d)       for dt seconds, then OFF
...
step N:  patch N ON  ((N-1)d - Nd)  for dt seconds, then OFF
```

```
patch width  d  = n x element size   (equals the beam diameter)
speed        v  = d / dt             (dt = d / v)
heat flux    q  = P / d^2
steps        N  = scan length / d
```

## Our two configurations

| | First trial | Case study |
|---|---|---|
| Patch | 2 × 2 elements (4), 10 × 10 mm | 3 × 3 elements (9), 15 × 15 mm |
| Step time | 1 s | 1 s |
| Speed | 10 mm/s | 15 mm/s |
| Steps over 150 mm | 15 | 10 |

For the case study: `q = 1500 W / (15 mm)^2 = 6.67 W/mm^2`; energy per step is 1500 J; line energy `P / v = 100 J/mm`.

Use `tools/patch_schedule.py` to print the patch layout and timing for any combination:

```
python tools/patch_schedule.py --beam 15 --speed 15 --power 1500
python tools/patch_schedule.py --beam 10 --speed 10
python tools/patch_schedule.py --beam 15 --speed 7.5 --scans 2
```

## Why it is only an approximation

- The average speed is exact, but the instantaneous source jumps from patch to patch instead of moving smoothly.
- Flux is uniform over a square patch, whereas a real beam is closer to a Gaussian.
- The beam diameter has to be a whole number of elements, so it is limited by the mesh (5 mm here).
- Smaller patches and shorter time steps converge towards the continuous source; this convergence was not studied.

## Controlling each parameter independently

| Want to change | Change this | Keep fixed |
|---|---|---|
| Beam diameter | Patch size, and flux to keep the same power | Step time = d / v |
| Scan speed | Step time dt | Patch size and flux |
| Power | Heat flux q | Patch size and step time |
| Number of passes | Repeat the sequence of patches | Everything else |

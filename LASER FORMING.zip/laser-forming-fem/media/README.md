# Media

Place the simulation animations here (or link them if they are large):

- Temperature field animation (heat patch moving along the plate)
- Total deformation animation (bending of the plate)

Note for the deformation animation: ANSYS exaggerates deformation for visibility. The real maximum deformation in the case study is about **0.12 mm**.

GitHub accepts files up to 100 MB; for larger videos upload them to Drive or YouTube and add the links to the main README under "Demo videos".

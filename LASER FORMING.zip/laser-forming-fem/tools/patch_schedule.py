#!/usr/bin/env python3
"""
Patch schedule calculator for the step-wise moving heat source.

In the ANSYS model the laser is not moved continuously. Instead, a square
patch of surface elements is loaded with heat flux for one time step, then
removed, and the next adjacent patch is loaded for the following step.

    patch width  d  = n_elements x element_size   (equals the beam diameter)
    step time   dt  = d / v                       (sets the scan speed v)
    heat flux    q  = P / d^2                     (power spread over the patch)
    no. of steps    = ceil(scan_length / d)

Usage examples
    python tools/patch_schedule.py                        # case study (15 mm, 15 mm/s, 1500 W)
    python tools/patch_schedule.py --beam 10 --speed 10   # first trial (2 x 2 patch)
    python tools/patch_schedule.py --beam 15 --speed 7.5 --power 1500 --scans 2
"""
import argparse
import math


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--beam", type=float, default=15.0, help="beam diameter / patch width in mm (default 15)")
    p.add_argument("--speed", type=float, default=15.0, help="scan speed in mm/s (default 15)")
    p.add_argument("--power", type=float, default=1500.0, help="laser power in W (default 1500)")
    p.add_argument("--elem", type=float, default=5.0, help="in-plane element size in mm (default 5)")
    p.add_argument("--length", type=float, default=150.0, help="scan length in mm (default 150)")
    p.add_argument("--scans", type=int, default=1, help="number of passes over the same path (default 1)")
    a = p.parse_args()

    n = round(a.beam / a.elem)
    if n < 1:
        raise SystemExit("Beam diameter is smaller than one element; refine the mesh.")
    d = n * a.elem
    if abs(d - a.beam) > 1e-9:
        print(f"Note: beam {a.beam} mm is not a multiple of the {a.elem} mm element; using {d} mm ({n} x {n} elements).")

    dt = d / a.speed
    steps = math.ceil(a.length / d)
    flux = a.power / d**2  # W/mm^2
    heating_time = steps * dt

    print("Step-wise moving heat source")
    print("----------------------------")
    print(f"Patch               : {n} x {n} elements = {d:g} x {d:g} mm")
    print(f"Step time (dt)      : {dt:g} s   (v = d/dt = {d / dt:g} mm/s)")
    print(f"Heat flux on patch  : {flux:.3f} W/mm^2  = {flux * 1e6:.3e} W/m^2")
    print(f"Energy per step     : {a.power * dt:g} J;  line energy P/v = {a.power / a.speed:g} J/mm")
    print(f"Steps per pass      : {steps}  ->  {heating_time:g} s of heating per pass")
    if a.scans > 1:
        print(f"Passes              : {a.scans}  ->  {a.scans * steps} load steps in total")
    print()
    print("step  start_x[mm]  end_x[mm]  t_on[s]  t_off[s]")
    for k in range(steps):
        for s in range(a.scans):
            idx = s * steps + k
            t_on = idx * dt
            print(f"{idx + 1:>4}  {k * d:>11g}  {min((k + 1) * d, a.length):>9g}  {t_on:>7g}  {t_on + dt:>8g}")


if __name__ == "__main__":
    main()
